import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class SwingConverter extends JApplet implements ActionListener{
    JTextField t1;
    JComboBox c1,c2;
    JLabel name, l1, l2, l3, l4;
    String[] currency={"Dollar","Rupee","Pound","Euro","Driham","Yaun"};
    public void init(){
        try{SwingUtilities.invokeAndWait(new Runnable(){
            public void run(){
                GUI();
            }
        });
        }catch(Exception e){}
    }
    public void actionPerformed(ActionEvent e2) {
        double zn, mnoz = 0;
        zn = Double.valueOf(t1.getText());
        try {
            if (c1.getSelectedIndex() == 0 & c2.getSelectedIndex() == 1) mnoz = zn * 60.335;
            if (c1.getSelectedIndex() == 0 & c2.getSelectedIndex() == 2) mnoz = zn * 0.595;
            if (c1.getSelectedIndex() == 0 & c2.getSelectedIndex() == 3) mnoz = zn * 0.723;
            if (c1.getSelectedIndex() == 0 & c2.getSelectedIndex() == 4) mnoz = zn * 3.673;
            if (c1.getSelectedIndex() == 0 & c2.getSelectedIndex() == 5) mnoz = zn * 6.221;
            if (c1.getSelectedIndex() == 1 & c2.getSelectedIndex() == 0) mnoz = zn * 0.017;
            if (c1.getSelectedIndex() == 1 & c2.getSelectedIndex() == 2) mnoz = zn * 0.01;
            if (c1.getSelectedIndex() == 1 & c2.getSelectedIndex() == 3) mnoz = zn * 0.012;
            if (c1.getSelectedIndex() == 1 & c2.getSelectedIndex() == 4) mnoz = zn * 0.06;
            if (c1.getSelectedIndex() == 1 & c2.getSelectedIndex() == 5) mnoz = zn * 0.103;
            if (c1.getSelectedIndex() == 2 & c2.getSelectedIndex() == 0) mnoz = zn * 1.679;
            if (c1.getSelectedIndex() == 2 & c2.getSelectedIndex() == 1) mnoz = zn * 101.251;
            if (c1.getSelectedIndex() == 2 & c2.getSelectedIndex() == 3) mnoz = zn * 1.215;
            if (c1.getSelectedIndex() == 2 & c2.getSelectedIndex() == 4) mnoz = zn * 6.17;
            if (c1.getSelectedIndex() == 2 & c2.getSelectedIndex() == 5) mnoz = zn * 10.45;
            if (c1.getSelectedIndex() == 3 & c2.getSelectedIndex() == 0) mnoz = zn * 1.382;
            if (c1.getSelectedIndex() == 3 & c2.getSelectedIndex() == 1) mnoz = zn * 83.333;
            if (c1.getSelectedIndex() == 3 & c2.getSelectedIndex() == 2) mnoz = zn * 0.823;
            if (c1.getSelectedIndex() == 3 & c2.getSelectedIndex() == 4) mnoz = zn * 5.079;
            if (c1.getSelectedIndex() == 3 & c2.getSelectedIndex() == 5) mnoz = zn * 8.601;
            if (c1.getSelectedIndex() == 4 & c2.getSelectedIndex() == 0) mnoz = zn * 0.909;
            if (c1.getSelectedIndex() == 4 & c2.getSelectedIndex() == 1) mnoz = zn * 54.795;
            if (c1.getSelectedIndex() == 4 & c2.getSelectedIndex() == 2) mnoz = zn * 0.541034;
            if (c1.getSelectedIndex() == 4 & c2.getSelectedIndex() == 3) mnoz = zn * 0.658;
            if (c1.getSelectedIndex() == 4 & c2.getSelectedIndex() == 4) mnoz = zn * 3.339;
            if (c1.getSelectedIndex() == 4 & c2.getSelectedIndex() == 5) mnoz = zn * 5.655;
            if (c1.getSelectedIndex() == 5 & c2.getSelectedIndex() == 0) mnoz = zn * 0.272;
            if (c1.getSelectedIndex() == 5 & c2.getSelectedIndex() == 1) mnoz = zn * 16.409;
            if (c1.getSelectedIndex() == 5 & c2.getSelectedIndex() == 2) mnoz = zn * 0.162;
            if (c1.getSelectedIndex() == 5 & c2.getSelectedIndex() == 3) mnoz = zn * 0.197;
            if (c1.getSelectedIndex() == 5 & c2.getSelectedIndex() == 4) mnoz = zn * 0.299;
            if (c1.getSelectedIndex() == 5 & c2.getSelectedIndex() == 6) mnoz = zn * 1.695;
            if (c1.getSelectedIndex() == 6 & c2.getSelectedIndex() == 0) mnoz = zn * 0.161;
            if (c1.getSelectedIndex() == 6 & c2.getSelectedIndex() == 1) mnoz = zn * 9.689;
            if (c1.getSelectedIndex() == 6 & c2.getSelectedIndex() == 2) mnoz = zn * 0.096;
            if (c1.getSelectedIndex() == 6 & c2.getSelectedIndex() == 3) mnoz = zn * 0.116;
            if (c1.getSelectedIndex() == 6 & c2.getSelectedIndex() == 4) mnoz = zn * 0.177;
            if (c1.getSelectedIndex() == 6 & c2.getSelectedIndex() == 5) mnoz = zn * 0.59;
            l4.setText(String.valueOf(mnoz));
        } catch (Exception e3){}
    }
    private void GUI(){
        GridBagLayout bagLayout = new GridBagLayout();
        GridBagConstraints constraints = new GridBagConstraints();
        setLayout(bagLayout);
        c1=new JComboBox(currency);
        c1.setSelectedIndex(0);
        c2=new JComboBox(currency);
        c2.setSelectedIndex(1);
        t1=new JTextField(10);
        name = new JLabel("Currency Converter");
        l1 = new JLabel("Input Currency:");
        l2 = new JLabel("Amount:  ");
        l3 = new JLabel("Output Currency:");
        l4 = new JLabel("  ");
        constraints.gridwidth = GridBagConstraints.REMAINDER;
        constraints.anchor = GridBagConstraints.NORTH;
        bagLayout.setConstraints(name, constraints);
        constraints.anchor = GridBagConstraints.EAST;
        constraints.gridwidth = GridBagConstraints.RELATIVE;
        bagLayout.setConstraints(l1, constraints);
        constraints.gridwidth = GridBagConstraints.REMAINDER;
        bagLayout.setConstraints(c1, constraints);
        constraints.gridwidth = GridBagConstraints.RELATIVE;
        bagLayout.setConstraints(l2, constraints);
        constraints.gridwidth = GridBagConstraints.REMAINDER;
        bagLayout.setConstraints(t1, constraints);
        constraints.gridwidth = GridBagConstraints.RELATIVE;
        bagLayout.setConstraints(l3, constraints);
        constraints.gridwidth = GridBagConstraints.REMAINDER;
        bagLayout.setConstraints(c2, constraints);
        constraints.gridwidth = GridBagConstraints.REMAINDER;
        bagLayout.setConstraints(l4, constraints);
        add(name);
        add(l1);
        add(c1);
        add(l2);
        add(t1);
        add(l3);
        add(c2);
        add(l4);
        t1.addActionListener(this);
        c1.addActionListener(this);
        c2.addActionListener(this);
    }
}